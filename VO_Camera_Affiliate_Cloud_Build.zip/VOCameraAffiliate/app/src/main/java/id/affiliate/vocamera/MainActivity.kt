package id.affiliate.vocamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var chooseAudioButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var audioUri: Uri? = null
    private var player: ExoPlayer? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var isRecording = false
    private var stoppingFromAudioEnd = false

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            audioUri = uri
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            chooseAudioButton.text = "Voice-over dipilih ✓"
            status.text = "Audio siap. Tekan Mulai Rekam."
            updateButtons()
        }
    }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else {
            status.text = "Izin kamera diperlukan untuk menggunakan aplikasi."
            updateButtons()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionRequest.launch(Manifest.permission.CAMERA)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xFF18181B.toInt())
        }
        val heading = TextView(this).apply {
            text = "VO CAMERA AFFILIATE"
            textSize = 21f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 10)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        status = TextView(this).apply {
            text = "Pilih voice-over terlebih dahulu."
            textSize = 14f
            setTextColor(0xFFE4E4E7.toInt())
            setPadding(0, 10, 0, 10)
        }
        chooseAudioButton = Button(this).apply {
            text = "1. Pilih voice-over (MP3/WAV)"
            setOnClickListener { audioPicker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/*")) }
        }
        startButton = Button(this).apply {
            text = "2. Mulai Rekam"
            isEnabled = false
            setOnClickListener { startRecordingWithAudio() }
        }
        stopButton = Button(this).apply {
            text = "Berhenti Manual"
            isEnabled = false
            setOnClickListener { stopRecording(manual = true) }
        }
        val note = TextView(this).apply {
            text = "Video disimpan ke Galeri. Mikrofon tidak digunakan. Target 1080p/30 fps jika didukung kamera."
            textSize = 12f
            setTextColor(0xFFA1A1AA.toInt())
            setPadding(0, 8, 0, 0)
        }
        root.addView(heading)
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status)
        root.addView(chooseAudioButton)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(note)
        setContentView(root)
        updateButtons()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.fromOrderedList(
                            listOf(Quality.FHD, Quality.HD, Quality.SD)
                        )
                    ).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture)
                status.text = "Kamera siap. Pilih voice-over."
            } catch (e: Exception) {
                status.text = "Kamera gagal dibuka: ${e.localizedMessage ?: "kesalahan tidak diketahui"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startRecordingWithAudio() {
        if (isRecording) return
        val selectedAudio = audioUri ?: run {
            Toast.makeText(this, "Pilih file voice-over dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val capture = videoCapture ?: run {
            Toast.makeText(this, "Kamera belum siap.", Toast.LENGTH_SHORT).show()
            return
        }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VO_Affiliate_$stamp.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VO Camera Affiliate")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        stoppingFromAudioEnd = false
        isRecording = true
        updateButtons()
        status.text = "Merekam dan memutar voice-over…"

        recording = capture.output
            .prepareRecording(this, output)
            // Audio recording deliberately NOT enabled: video is silent; original VO can be added in editor.
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        val exo = ExoPlayer.Builder(this).build()
                        player = exo
                        exo.addListener(object : Player.Listener {
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                if (playbackState == Player.STATE_ENDED && isRecording) {
                                    stoppingFromAudioEnd = true
                                    stopRecording(manual = false)
                                }
                            }
                            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                                status.text = "Audio gagal diputar; rekaman dihentikan."
                                stopRecording(manual = false)
                            }
                        })
                        exo.setMediaItem(MediaItem.fromUri(selectedAudio))
                        exo.prepare()
                        exo.play()
                    }
                    is VideoRecordEvent.Finalize -> {
                        isRecording = false
                        recording = null
                        releasePlayer()
                        updateButtons()
                        if (event.hasError()) {
                            status.text = "Rekaman gagal diselesaikan. Coba lagi."
                        } else {
                            status.text = if (stoppingFromAudioEnd) {
                                "Selesai. Video tersimpan di Galeri → Movies/VO Camera Affiliate."
                            } else {
                                "Video tersimpan di Galeri → Movies/VO Camera Affiliate."
                            }
                            Toast.makeText(this, "Video tersimpan.", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
    }

    private fun stopRecording(manual: Boolean) {
        if (!isRecording) return
        if (manual) stoppingFromAudioEnd = false
        releasePlayer()
        recording?.stop()
        status.text = if (manual) "Menghentikan rekaman…" else "Voice-over selesai. Menyimpan video…"
        stopButton.isEnabled = false
    }

    private fun releasePlayer() {
        player?.let {
            it.stop()
            it.release()
        }
        player = null
    }

    private fun updateButtons() {
        chooseAudioButton.isEnabled = !isRecording
        startButton.isEnabled = !isRecording && audioUri != null && videoCapture != null
        stopButton.isEnabled = isRecording
    }

    override fun onDestroy() {
        releasePlayer()
        if (isRecording) recording?.stop()
        super.onDestroy()
    }
}
